package choose

import "errors"

var ErrNoChoices = errors.New("no choices available")
