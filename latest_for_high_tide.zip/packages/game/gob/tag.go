package gob

type Tag struct {
	Key   string
	Value string
}
