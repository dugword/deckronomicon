package static_abilities

type FlashbackModifiers struct {
	Cost string
}
