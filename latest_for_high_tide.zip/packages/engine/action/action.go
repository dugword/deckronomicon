package action

// TODO: Do I still need this?
/*
type ResolutionEnvironment struct {
	EffectRegistry *effect.EffectRegistry
	Definitions    map[string]definition.Card
	// definitions maybe should live here too
}
*/
