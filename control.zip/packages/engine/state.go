package engine

func NewGameState() *GameState {
	return &GameState{}
}

func (g *GameState) IsGameOver() bool {
	return false // TODO: real logic
}

type GameStateSnapshot struct {
	Turn int
}
