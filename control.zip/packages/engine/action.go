package engine

type TurnBasedAction interface {
	Name() string
	Description() string
	Complete()
}
