package engine

import "fmt"

type GameState struct {
	turn  int
	stack Stack
}

type Stack struct {
	items []StackItem
}

type StackItem struct {
	Source     string                 // Player ID or Card ID
	Controller string                 // Player ID
	Effect     func(*GameState) error // Function to resolve the effect
}

func (s *StackItem) Resolve(state *GameState) error {
	return nil
}

func (s *Stack) IsEmpty() bool {
	return len(s.items) == 0
}

func (s *Stack) Pop() (*StackItem, error) {
	if len(s.items) == 0 {
		return nil, fmt.Errorf("stack is empty")
	}
	item := s.items[len(s.items)-1]
	s.items = s.items[:len(s.items)-1]
	return &item, nil
}

func (s *Stack) Push(item StackItem) {
	s.items = append(s.items, item)
}

type Engine struct {
	agents  map[string]PlayerAgent
	players []*Player
	state   *GameState
	record  *GameRecord
	rng     *RNG
}

type EngineConfig struct {
	Players []*Player
	Agents  map[string]PlayerAgent
	Seed    int64
	// Cards are just strings for now, but will be a Card type later
	DeckLists map[string][]string
}

func NewEngine(config EngineConfig) *Engine {
	agents := map[string]PlayerAgent{}
	for id, agent := range config.Agents {
		agents[id] = agent
	}
	return &Engine{
		agents:  agents,
		players: config.Players,
		state:   NewGameState(),
		record:  NewGameRecord(config.Seed),
		rng:     NewRNG(config.Seed),
	}
}

func (e *Engine) RunGame() error {
	fmt.Println("Running game...")
	// shuffle all player decks
	// draw initial hands for players
	// resovle mulligans
	for !e.state.IsGameOver() {
		for _, player := range e.players {
			fmt.Println("Starting turn for player:", player.id)
			err := e.RunTurn(player)
			if err != nil {
				return err
			}
		}
	}
	return nil
}

// TODO: This is a placer holder, phases and steps will be more complex later
type Phase struct {
	Name  string
	Steps []Step
}

// TODO: This is a placer holder, phases and steps will be more complex later
type Step struct {
	Name    string
	Actions []TurnBasedAction
}

func (e *Engine) RunTurn(player *Player) error {
	fmt.Println("Running turn for player:", player.id)
	// This is a place holder, phases will be a struct later
	for _, phase := range []Phase{Phase{
		Name: "Beginning",
		Steps: []Step{Step{
			Name:    "Draw",
			Actions: []TurnBasedAction{},
		}},
	}} {
		fmt.Println("Starting phase:", phase.Name)
		e.RunPhase(phase)
	}
	return nil
}

func (e *Engine) RunPhase(phase Phase) error {
	fmt.Println("Running phase:", phase.Name)
	for _, step := range phase.Steps {
		fmt.Println("Starting step:", step.Name)
		e.RunStep(step)
	}
	return nil
}

func (e *Engine) RunStep(step Step) error {
	fmt.Println("Running step:", step.Name)
	for _, action := range step.Actions {
		fmt.Println("Completing action:", action.Name())
		action.Complete()
	}
	for _, player := range e.players {
		fmt.Println("Starting priority for player:", player.id)
		e.RunPriority(player)
		for {
			if e.state.stack.IsEmpty() {
				break
			}
			if stackItem, err := e.state.stack.Pop(); err != nil {
				_ = stackItem.Resolve(e.state)
			}
			e.RunPriority(player)
		}
	}
	return nil
}

func (e *Engine) RunPriority(player *Player) {
	for {
		fmt.Println("Running priority for player:", player.id)
		agent := e.agents[player.id]
		action := agent.GetNextAction()
		if action == "pass" {
			fmt.Println("Player", player.id, "passed priority.")
			break
		}
	}
}
