package engine

type Player struct {
	id string
}

func NewPlayer(id string) *Player {
	return &Player{
		id: id,
	}
}
