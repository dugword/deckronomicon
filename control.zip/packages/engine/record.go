package engine

type GameEvent struct {
	Turn        int
	Phase       string
	Action      string
	Source      string
	Targets     []string
	Choices     []string
	Result      string
	RNGSnapshot int64
}

type GameRecord struct {
	Seed       int64
	Events     []GameEvent
	FinalState GameStateSnapshot
}

func NewGameRecord(seed int64) *GameRecord {
	return &GameRecord{
		Seed:   seed,
		Events: []GameEvent{},
	}
}

func (r *GameRecord) AddEvent(e GameEvent) {
	r.Events = append(r.Events, e)
}
